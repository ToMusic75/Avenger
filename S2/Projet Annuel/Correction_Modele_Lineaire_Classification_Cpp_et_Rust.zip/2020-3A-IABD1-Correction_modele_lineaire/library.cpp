#include <random>
#include <iostream>

#if _WIN32
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT
#endif

extern "C" {
DLLEXPORT double *linear_create_model(int nb_features) {
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_real_distribution<double> dist(-1.0, 1.0);
    auto w = new double[nb_features + 1];
    for (auto i = 0; i < nb_features + 1; i++) {
        w[i] = dist(mt);
    }
    return w;
}

DLLEXPORT double linear_predict_model_regression(const double *model, const double *inputs, int inputs_size) {
    auto sum = model[0];
    for (auto i = 0; i < inputs_size; i++) {
        sum += model[i + 1] * inputs[i];
    }
    return sum;
}

DLLEXPORT double linear_predict_model_classification(const double *model, const double *inputs, int inputs_size) {
    auto sum = linear_predict_model_regression(model, inputs, inputs_size);
    auto return_val =  sum >= 0 ? 1.0 : -1.0;
    return return_val;
}

DLLEXPORT void linear_dispose_model(const double *model) {
    delete[] model;
}

DLLEXPORT void linear_train_model_classification(
        double *model,
        const double *dataset_inputs,
        const double *dataset_expected_outputs,
        int dataset_samples_count,
        int dataset_sample_features_count,
        double alpha, // learning rate
        int iteration_count
) {
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_int_distribution<int> dist(0, dataset_samples_count - 1);

    for (auto it = 0; it < iteration_count; it++) {
        auto k = dist(mt);
        auto inputs_k = dataset_inputs + k * dataset_sample_features_count;

        auto expected_output_k = dataset_expected_outputs[k];

        auto predicted_output_k = linear_predict_model_classification(model, inputs_k, dataset_sample_features_count);

        auto semi_grad = alpha * (expected_output_k - predicted_output_k);
        for (auto i = 0; i < dataset_sample_features_count; i++) {
            model[i + 1] += semi_grad * inputs_k[i];
        }
        model[0] += semi_grad * 1.0;
    }
}

}